# Trusted Node renderer A/B: 7faf7f40 vs c25f74c3

Captured 2026-08-24 on one Apple M4 host with Node 26.5.0 and `@pmndrs/labs` 0.6.0. Browser/GPU capture was not run concurrently by this workstream. Every Labs case ran in an isolated worker with inner GC, clock-drift checks, adaptive log-space confidence sampling, Mann-Whitney U (`alpha=0.05`), a 3% practical delta, and Cliff's d >= 0.474.

## Provenance

- Baseline: `7faf7f400a20741f9686bd15a3e9a0652c4c15fd`, clean detached worktree `/private/tmp/three-flatland-node-ab-7faf`
- API-sealing checkpoint: `b153a583b08109938057c8d9065edc5e7ba435d9`, clean detached worktree `/private/tmp/three-flatland-node-ab-b153`
- Release candidate: `c25f74c3e37bb9b521d416a81d749c925df00df2`, clean worktree `/private/tmp/three-flatland-internal-ecs-release-stack`
- Lockfile SHA-256 at baseline and candidate: `35208220e7fa7b483aecfbab3edd91d679e0ab44399bb881b2002848ae5a924b`
- Labs harness/config SHA-256 values are recorded in `SHA256SUMS`.
- The old and final custom renderer harness measurement loop is unchanged. Its source-only differences are untimed private-accessor validation/provenance changes.

## Workload

The production Labs fixture creates the same representative `SpriteGroup` source topology for both revisions. Setup, initial assignment, assertions, and next-frame mutation are outside the timed callback; the timed callback is only `group.update()`.

- static 16,384
- moving alpha/depth 16,384
- transparent sort 16,384
- routing 12,000 of 16,384
- static 60,000
- moving alpha/depth 60,000

The tightened 60k runs used `adaptive=0.005`, `minCpuTime=5`, `maxCpuTime=30`, `minSamples=100`, and `maxSamples=20,000`.

## Verdict

There is no trusted production regression at c25.

The first broad old-first pair classified both 60k cases slower at c25 (+13.0% static, +9.4% moving), while all four 16k/routing cases were neutral. The reverse-order pair preserved a nominal 60k direction (+about 5% static and +about 8% moving at c25) but classified every case neutral because the effective noise bands were larger.

The tighter 60k pair then measured:

| Case | 7faf p50 | c25 p50 | Delta | Labs verdict | Effective noise |
| --- | ---: | ---: | ---: | --- | ---: |
| static 60,000 | 31.48 ms | 31.74 ms | +0.8% | neutral | +/-8% |
| moving alpha/depth 60,000 | 33.15 ms | 32.05 ms | -3.3% | neutral | +/-11% |

Both CPUs were stable at approximately 4.00-4.03 GHz and every measurement was stable/non-noisy. The earlier broad custom-harness warning was therefore variance-sensitive and must not be treated as a release blocker.

The b153 sealing checkpoint cannot attribute a regression. It measured +6.6%/+6.8% against old in one sequence, but b153 and c25 have identical timed transform code (the only later transform diff is formatting), while c25 measured -5.4%/-9.4% against b153. That same-code separation is direct evidence of run-to-run variance.

## Instrumented diagnosis

Development/instrumented Labs measured c25 at +6.9% static and +7.9% moving for 60k, with p < .001, but Labs still classified both neutral because the effective noise bands were +/-8% and +/-13%.

The deterministic custom harness agrees on attribution, not verdict: its 60k static total moved 26.13 -> 28.45 ms (+8.87%) and transformSync moved 25.96 -> 28.31 ms (+9.08%); moving total moved 30.07 -> 32.18 ms (+7.01%) and transformSync moved 29.92 -> 32.04 ms (+7.07%). Other system medians are effectively flat. These artifacts remain valuable for topology and per-system attribution but their hand-rolled medians are not a trusted performance gate.

One source-level cost is real and deterministic: the private API sealing replaced a direct `sprite.entity` read with one `spriteEntity(sprite)` WeakMap lookup per occupied row after virtual `updateMatrix()` returns. At 60,000 sprites this is exactly 60,000 WeakMap gets per frame. An isolated Labs microbenchmark measured:

| Ownership check, 60,000 calls | p50 | Delta vs previous | Labs verdict |
| --- | ---: | ---: | --- |
| direct numeric property | 43.75 us | - | baseline |
| packed-owner registry identity | 77.58 us | +77.3% / +33.83 us | slower |
| WeakMap get | 552.73 us | +612.4% / +475.15 us | slower |

This bounds the avoidable WeakMap cost near 0.48 ms per 60k checks on this host. It is a microbenchmark result, not proof of a whole-frame regression.

The smallest allocation-free, private-boundary-preserving candidate is to replace the WeakMap read in `transformSyncSystem` with the already-owned registry identity check `registry.spriteArr[entitySlot(owner)] === sprite`. The registry row is nulled before deferred batch removal, so it preserves the reentrant remove/dispose stale-row guard; `slotEntities`, `spriteAtSlot`, `_batchMesh`, and `_batchSlot` continue to protect row replacement and forward ownership. An external candidate passed all 36 `entityLifecycle` tests. Its first whole-frame Labs run is preserved but rejected because CPU frequency drifted 5.1%; it is not merge evidence and no release-stack edit was made.

## Recommended repository integration

Add a minimal trusted timing lane under the private `tools/ecs-bench` package:

1. Add `@pmndrs/labs` as a pinned dev dependency.
2. Add `labs.config.ts` with the comparison thresholds above and a `benches/renderer-frame.bench.ts` generator fixture.
3. Add a non-cacheable Nx target such as `benchmark:labs` that accepts Labs tags/names. Keep `NODE_ENV=production` as the release verdict path; use development only for diagnosis.
4. Preserve the existing renderer evidence runner for deterministic topology, ownership, per-system User Timing, memory, GC, source provenance, and 60k coverage. Stop using its wall-time medians as the performance verdict.
5. Run saved baseline/candidate comparisons serially on the same idle host. Reject unstable-clock or noisy artifacts. Do not make shared CI runners a hard statistical gate; use CI for fixture/type smoke and controlled-host evidence for release comparisons.

Suggested tags are `@renderer-frame`, `@scale`, and `@lookup`; setup and mutations must stay outside the measured callback, and `.gc('inner')` must remain enabled.

## Command forms

All Labs runs used the external harness directory `/private/tmp/three-flatland-labs-renderer-ab`. The first four broad runs were captured before the lookup microbenchmark file was added, so they did not require a tag filter. The equivalent current-harness commands use `@renderer-frame` below; the renderer scenario code is unchanged.

```sh
env NODE_ENV=production FLATLAND_BENCH_TARGET=old node node_modules/@pmndrs/labs/dist/cli.mjs '@renderer-frame' -n old-prod-r1
env NODE_ENV=production FLATLAND_BENCH_TARGET=head node node_modules/@pmndrs/labs/dist/cli.mjs '@renderer-frame' -n head-prod-r1
env NODE_ENV=production FLATLAND_BENCH_TARGET=head node node_modules/@pmndrs/labs/dist/cli.mjs '@renderer-frame' -n head-prod-r2
env NODE_ENV=production FLATLAND_BENCH_TARGET=old node node_modules/@pmndrs/labs/dist/cli.mjs '@renderer-frame' -n old-prod-r2
env NODE_ENV=production FLATLAND_BENCH_TARGET=old node node_modules/@pmndrs/labs/dist/cli.mjs '@scale' -n old-scale-r3
env NODE_ENV=production FLATLAND_BENCH_TARGET=head node node_modules/@pmndrs/labs/dist/cli.mjs '@scale' -n head-scale-r3
env NODE_ENV=production FLATLAND_BENCH_TARGET=sealed node node_modules/@pmndrs/labs/dist/cli.mjs '@scale' -n sealed-scale-r3
env NODE_ENV=development FLATLAND_BENCH_TARGET=old node node_modules/@pmndrs/labs/dist/cli.mjs '@scale' -n old-dev-scale-r1
env NODE_ENV=development FLATLAND_BENCH_TARGET=head node node_modules/@pmndrs/labs/dist/cli.mjs '@scale' -n head-dev-scale-r1
env ENTITY_LOOKUP_TARGET=field node node_modules/@pmndrs/labs/dist/cli.mjs '@lookup' -n entity-field-r2
env ENTITY_LOOKUP_TARGET=registry node node_modules/@pmndrs/labs/dist/cli.mjs '@lookup' -n entity-registry-r1
env ENTITY_LOOKUP_TARGET=weakmap node node_modules/@pmndrs/labs/dist/cli.mjs '@lookup' -n entity-weakmap-r2
```

The external candidate command was identical to the production scale command with `FLATLAND_BENCH_TARGET=candidate`; its result is `candidate-scale-r1.json` and is intentionally retained despite the unstable-clock warning.
