import { createRequire } from 'node:module'

const require = createRequire('/private/tmp/three-flatland-internal-ecs-release-stack/package.json')
const { chromium } = require('@playwright/test')
const browser = await chromium.launch({
  channel: 'chrome',
  headless: false,
  args: ['--enable-gpu', '--ignore-gpu-blocklist', '--enable-unsafe-webgpu', '--use-angle=metal'],
})
const context = await browser.newContext({ viewport: { width: 1280, height: 720 } })
const page = await context.newPage()
const failures = []
page.on('pageerror', (error) => failures.push(`page: ${error.message}`))
page.on('console', (message) => {
  if (message.type() === 'error' && !message.text().startsWith('Failed to load resource:')) {
    failures.push(`console: ${message.text()}`)
  }
})
page.on('response', (response) => {
  if (response.status() >= 400 && !response.url().endsWith('/favicon.ico')) {
    failures.push(`http ${response.status()}: ${response.url()}`)
  }
})

try {
  await page.goto('http://127.0.0.1:55432/', { waitUntil: 'load' })
  await page.waitForFunction(() => {
    const canvas = document.querySelector('canvas')
    return canvas && canvas.width > 0 && canvas.height > 0 && !document.querySelector('#loader')
  })
  await page.locator('[aria-label="Enter fullscreen"]').waitFor({ state: 'visible' })
  const canvas = page.locator('canvas').first()
  const box = await canvas.boundingBox()
  if (!box) throw new Error('starter-react production canvas has no layout box')
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2)
  await page.mouse.down()
  await page.mouse.up()
  const framesAdvance = await page.evaluate(
    () => new Promise((resolve) => requestAnimationFrame((first) => requestAnimationFrame((second) => resolve(second > first))))
  )
  if (!framesAdvance) throw new Error('starter-react production RAF did not advance')
  if (failures.length > 0) throw new Error(failures.join(' | '))
  await page.screenshot({
    path: '/private/tmp/three-flatland-final-example-smoke-c7b55928/screenshots/starter-react-production.png',
  })
  console.log('STARTER_REACT_PRODUCTION_PASS')
} finally {
  await context.close()
  await browser.close()
}
