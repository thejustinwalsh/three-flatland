import { createRequire } from 'node:module'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'

const root = '/private/tmp/three-flatland-internal-ecs-release-stack'
const output = '/private/tmp/three-flatland-final-example-smoke-c7b55928'
const snippet = readFileSync(resolve(output, 'final-smoke.js'), 'utf8')
const require = createRequire(`${root}/package.json`)
const { chromium } = require('@playwright/test')
const { runVitexec } = await import(
  'file:///Users/mini/Library/Caches/pnpm/dlx/44f7673e04ea4b8b0c8df19670dfc3573b08332382f67e345a15b98069cda483/1a027ec84ea-5ff9/node_modules/.pnpm/vitexec@0.2.0_vite@8.2.2/node_modules/vitexec/dist/cli.js'
)

const cases = [
  ['three-animation', 'examples/three/animation', '/three/animation/?smokeCase=three-animation'],
  ['three-basic-sprite', 'examples/three/basic-sprite', '/three/basic-sprite/?smokeCase=three-basic-sprite'],
  ['three-batch-demo', 'examples/three/batch-demo', '/three/batch-demo/?smokeCase=three-batch-demo'],
  ['three-hierarchy-clipping', 'examples/three/hierarchy-clipping', '/three/hierarchy-clipping/?smokeCase=three-hierarchy-clipping'],
  ['three-hit-test', 'examples/three/hit-test', '/three/hit-test/?smokeCase=three-hit-test'],
  ['three-knightmark', 'examples/three/knightmark', '/three/knightmark/?bench=1&sprites=10&seed=12648430&fixedDelta=16.666&smokeCase=three-knightmark'],
  ['three-lighting', 'examples/three/lighting', '/three/lighting/?bench=1&slimes=5&lights=5&seed=12648430&fixedDelta=16.666&smokeCase=three-lighting'],
  ['three-pass-effects', 'examples/three/pass-effects', '/three/pass-effects/?smokeCase=three-pass-effects'],
  ['three-skia', 'examples/three/skia', '/three/skia/?smokeCase=three-skia'],
  ['three-slug-text', 'examples/three/slug-text', '/three/slug-text/?smokeCase=three-slug-text'],
  ['three-template', 'examples/three/template', '/three/template/?smokeCase=three-template'],
  ['three-tilemap', 'examples/three/tilemap', '/three/tilemap/?smokeCase=three-tilemap'],
  ['three-tsl-nodes', 'examples/three/tsl-nodes', '/three/tsl-nodes/?smokeCase=three-tsl-nodes'],
  ['react-animation', 'examples/react/animation', '/react/animation/?smokeCase=react-animation'],
  ['react-basic-sprite', 'examples/react/basic-sprite', '/react/basic-sprite/?smokeCase=react-basic-sprite'],
  ['react-batch-demo', 'examples/react/batch-demo', '/react/batch-demo/?smokeCase=react-batch-demo'],
  ['react-hierarchy-clipping', 'examples/react/hierarchy-clipping', '/react/hierarchy-clipping/?smokeCase=react-hierarchy-clipping'],
  ['react-hit-test', 'examples/react/hit-test', '/react/hit-test/?smokeCase=react-hit-test'],
  ['react-knightmark', 'examples/react/knightmark', '/react/knightmark/?bench=1&sprites=10&seed=12648430&fixedDelta=16.666&smokeCase=react-knightmark'],
  ['react-lighting', 'examples/react/lighting', '/react/lighting/?bench=1&slimes=5&lights=5&seed=12648430&fixedDelta=16.666&smokeCase=react-lighting'],
  ['react-pass-effects', 'examples/react/pass-effects', '/react/pass-effects/?smokeCase=react-pass-effects'],
  ['react-skia', 'examples/react/skia', '/react/skia/?smokeCase=react-skia'],
  ['react-slug-text', 'examples/react/slug-text', '/react/slug-text/?smokeCase=react-slug-text'],
  ['react-template', 'examples/react/template', '/react/template/?smokeCase=react-template'],
  ['react-tilemap', 'examples/react/tilemap', '/react/tilemap/?smokeCase=react-tilemap'],
  ['react-tsl-nodes', 'examples/react/tsl-nodes', '/react/tsl-nodes/?smokeCase=react-tsl-nodes'],
  ['starter-three', 'packages/create-three-flatland/templates/three', '/?smokeCase=starter-three'],
  ['starter-react', 'packages/create-three-flatland/templates/react', '/?smokeCase=starter-react'],
]

mkdirSync(resolve(output, 'logs'), { recursive: true })
mkdirSync(resolve(output, 'screenshots'), { recursive: true })
const results = []

const browser = await chromium.launch({
  channel: 'chrome',
  headless: false,
  args: ['--enable-gpu', '--ignore-gpu-blocklist', '--enable-unsafe-webgpu', '--use-angle=metal'],
})

try {
  for (const [name, directory, path] of cases) {
    process.stdout.write(`[${results.length + 1}/${cases.length}] ${name}\n`)
    const code = `history.replaceState(null, '', ${JSON.stringify(path)});\n${snippet.replaceAll('__SMOKE_CASE__', name)}`
    const benchmarkPath = name.includes('knightmark') || name.includes('lighting')
      ? `/${new URL(path, 'http://vitexec.local').search}`
      : undefined
    const lines = []
    let error = null
    try {
      for await (const line of runVitexec(code, {
        browser,
        configFile: name === 'starter-react' ? false : undefined,
        path: benchmarkPath,
        root: resolve(root, directory),
        screenshotPath: resolve(output, 'screenshots', `${name}.png`),
        timeoutMs: 120_000,
      })) {
        lines.push(line)
      }
    } catch (caught) {
      error = caught instanceof Error ? caught.stack ?? caught.message : String(caught)
    }
    const log = `${lines.join('\n')}\n${error ?? ''}`
    writeFileSync(resolve(output, 'logs', `${name}.log`), log)
    const passed = error === null && log.includes('SMOKE_PASS') && !log.includes('[error] timeout')
    results.push({ name, directory, path, passed, error })
    process.stdout.write(`${passed ? 'PASS' : 'FAIL'} ${name}\n`)
    if (!passed) {
      process.stdout.write(log.slice(-4_000))
      break
    }
  }
} finally {
  await browser.close()
}

writeFileSync(resolve(output, 'results.json'), JSON.stringify({ root, results }, null, 2))
const passed = results.length === cases.length && results.every((result) => result.passed)
if (!passed) process.exitCode = 1
