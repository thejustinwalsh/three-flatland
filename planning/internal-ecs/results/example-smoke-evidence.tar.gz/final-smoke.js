const smokeCase = '__SMOKE_CASE__'

function assert(condition, message) {
  if (!condition) throw new Error(`${smokeCase}: ${message}`)
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

async function waitFor(read, label, timeout = 90_000) {
  const deadline = performance.now() + timeout
  while (performance.now() < deadline) {
    const value = read()
    if (value) return value
    await sleep(100)
  }
  throw new Error(`${smokeCase}: timed out waiting for ${label}`)
}

function isVisible(element) {
  if (!(element instanceof Element)) return false
  const style = getComputedStyle(element)
  const rect = element.getBoundingClientRect()
  return style.visibility !== 'hidden' && style.display !== 'none' && rect.width > 0 && rect.height > 0
}

function visibleCanvases() {
  return [...document.querySelectorAll('canvas')].filter(
    (canvas) => isVisible(canvas) && canvas.width > 0 && canvas.height > 0
  )
}

function splitHandle() {
  return (
    document.querySelector('#split-handle') ??
    [...document.querySelectorAll('div')].find(
      (element) => isVisible(element) && getComputedStyle(element).cursor === 'col-resize'
    )
  )
}

function pointer(target, fromX = 0.5, fromY = 0.5, toX = 0.58, toY = 0.56) {
  const rect = target.getBoundingClientRect()
  const startX = rect.left + rect.width * fromX
  const startY = rect.top + rect.height * fromY
  const endX = rect.left + rect.width * toX
  const endY = rect.top + rect.height * toY
  target.dispatchEvent(
    new PointerEvent('pointermove', {
      bubbles: true,
      clientX: startX,
      clientY: startY,
      pointerId: 1,
      pointerType: 'mouse',
    })
  )
  target.dispatchEvent(
    new PointerEvent('pointerdown', {
      bubbles: true,
      button: 0,
      buttons: 1,
      clientX: startX,
      clientY: startY,
      pointerId: 1,
      pointerType: 'mouse',
    })
  )
  target.dispatchEvent(
    new PointerEvent('pointermove', {
      bubbles: true,
      buttons: 1,
      clientX: endX,
      clientY: endY,
      movementX: endX - startX,
      movementY: endY - startY,
      pointerId: 1,
      pointerType: 'mouse',
    })
  )
  target.dispatchEvent(
    new PointerEvent('pointerup', {
      bubbles: true,
      button: 0,
      buttons: 0,
      clientX: endX,
      clientY: endY,
      pointerId: 1,
      pointerType: 'mouse',
    })
  )
  target.dispatchEvent(new MouseEvent('click', { bubbles: true, clientX: endX, clientY: endY }))
}

async function drag(target, fromX = 0.5, fromY = 0.5, toX = 1.5, toY = 0.5) {
  const rect = target.getBoundingClientRect()
  const startX = rect.left + rect.width * fromX
  const startY = rect.top + rect.height * fromY
  const endX = rect.left + rect.width * toX
  const endY = rect.top + rect.height * toY
  target.dispatchEvent(
    new PointerEvent('pointerdown', {
      bubbles: true,
      button: 0,
      buttons: 1,
      clientX: startX,
      clientY: startY,
      pointerId: 1,
      pointerType: 'mouse',
    })
  )
  await new Promise((resolve) => requestAnimationFrame(resolve))
  dispatchEvent(
    new PointerEvent('pointermove', {
      bubbles: true,
      buttons: 1,
      clientX: endX,
      clientY: endY,
      movementX: endX - startX,
      movementY: endY - startY,
      pointerId: 1,
      pointerType: 'mouse',
    })
  )
  await new Promise((resolve) => requestAnimationFrame(resolve))
  dispatchEvent(
    new PointerEvent('pointerup', {
      bubbles: true,
      button: 0,
      buttons: 0,
      clientX: endX,
      clientY: endY,
      pointerId: 1,
      pointerType: 'mouse',
    })
  )
}

function clickText(text) {
  const elements = [...document.querySelectorAll('button, [role="button"], label, option')]
  const match = elements.find((element) => isVisible(element) && element.textContent?.trim().includes(text))
  if (!match) return false
  if (match instanceof HTMLOptionElement && match.parentElement instanceof HTMLSelectElement) {
    match.parentElement.value = match.value
    match.parentElement.dispatchEvent(new Event('change', { bubbles: true }))
    match.parentElement.dispatchEvent(new Event('input', { bubbles: true }))
  } else if (match instanceof HTMLElement) {
    match.click()
  }
  return true
}

async function rafSamples() {
  const values = []
  for (let index = 0; index < 3; index++) {
    values.push(await new Promise((resolve) => requestAnimationFrame(resolve)))
  }
  assert(values[0] < values[1] && values[1] < values[2], 'RAF timestamps did not advance')
  return values
}

const runtimeErrors = []
addEventListener('error', (event) => runtimeErrors.push(String(event.error ?? event.message)))
addEventListener('unhandledrejection', (event) => runtimeErrors.push(String(event.reason)))

const isBenchmark = smokeCase.includes('knightmark') || smokeCase.includes('lighting')
let benchmark = null
if (isBenchmark) {
  benchmark = await waitFor(
    () => window.__THREE_FLATLAND_BENCHMARK__,
    'deterministic benchmark readiness',
    120_000
  )
  const expectedVariant = smokeCase.startsWith('react-') ? 'react' : 'three'
  const expectedExample = smokeCase.includes('lighting') ? 'lighting' : 'knightmark'
  assert(benchmark.variant === expectedVariant, `expected ${expectedVariant} benchmark variant`)
  assert(benchmark.example === expectedExample, `expected ${expectedExample} benchmark payload`)
  assert(benchmark.actualSprites === benchmark.requestedSprites, 'requested and actual sprites differ')
  assert(benchmark.actualBatches > 0, 'benchmark created no batches')
  assert(benchmark.simulationGated === true && benchmark.simulationFrame === 0, 'simulation was not gated')
  if (expectedExample === 'lighting') {
    assert(benchmark.actualLights === benchmark.requestedLights, 'requested and actual lights differ')
  }
  for (const field of ['vendor', 'architecture', 'device', 'description']) {
    assert(typeof benchmark.gpuAdapter[field] === 'string', `gpuAdapter.${field} is missing`)
  }
} else if (smokeCase.includes('slug-text')) {
  await waitFor(
    () => visibleCanvases().length >= 2 && splitHandle(),
    'Slug canvases and split handle',
    120_000
  )
  assert(document.body.textContent.includes('SLUG'), 'SLUG comparison label is missing')
  const computing = document.querySelector('#computing, [data-computing]')
  assert(!computing?.hasAttribute('data-visible'), 'Slug retained its computing state')
} else if (smokeCase.startsWith('starter-')) {
  await waitFor(
    () => visibleCanvases().length === 1 && !document.querySelector('#loader'),
    'starter canvas and loader removal',
    120_000
  )
  assert(document.querySelector('[aria-label="Enter fullscreen"]'), 'fullscreen affordance is missing')
} else {
  await waitFor(() => visibleCanvases().length > 0, 'visible canvas', 120_000)
  if (smokeCase.startsWith('react-')) await sleep(5_000)
}

const canvas = visibleCanvases()[0]
assert(canvas, 'no visible nonzero canvas after readiness')

if (isBenchmark) {
  window.__THREE_FLATLAND_BENCHMARK_START__()
  await waitFor(() => window.__THREE_FLATLAND_BENCHMARK_FRAME__ >= 2, 'two simulation frames')
  if (smokeCase.includes('knightmark')) {
    const add = document.querySelector('#btn-add')
    if (add instanceof HTMLElement) add.click()
  } else {
    document.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, code: 'KeyD', key: 'd' }))
    await sleep(150)
    document.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, code: 'KeyD', key: 'd' }))
  }
  await waitFor(() => window.__THREE_FLATLAND_BENCHMARK_FRAME__ >= 4, 'post-interaction simulation frames')
  window.__THREE_FLATLAND_BENCHMARK_PAUSE__()
} else if (smokeCase.includes('animation')) {
  assert(clickText('Run'), 'Run animation control is missing')
  await sleep(350)
  assert(clickText('Idle'), 'Idle animation control is missing')
} else if (smokeCase.includes('batch-demo')) {
  const tower = [...document.querySelectorAll('button')].find(
    (element) =>
      element.title.toLowerCase().includes('tower') ||
      element.textContent?.toLowerCase().includes('tower') ||
      element.querySelector('img[alt="tower" i]')
  )
  assert(tower, 'Tower selector is missing')
  tower.click()
} else if (smokeCase.includes('hierarchy-clipping')) {
  const expected = smokeCase.startsWith('react-') ? 'React Activity' : 'Nested transforms'
  assert(document.querySelector('#status')?.textContent.includes(expected), 'hierarchy status is incorrect')
  dispatchEvent(new Event('resize'))
} else if (smokeCase.includes('hit-test')) {
  pointer(canvas, 0.5, 0.5, 0.56, 0.5)
  await waitFor(
    () => [...document.querySelectorAll('span, #collected')].some((element) => element.textContent?.includes('Legendary')),
    'hit-test rarity HUD'
  )
} else if (smokeCase.includes('pass-effects')) {
  const preset = await waitFor(
    () => [...document.querySelectorAll('select')].find((select) =>
      [...select.options].some((option) => option.textContent?.includes('CRT Arcade'))
    ),
    'CRT Arcade control'
  )
  const arcade = [...preset.options].find((option) => option.textContent?.includes('CRT Arcade'))
  assert(arcade, 'CRT Arcade option is missing')
  preset.value = arcade.value
  preset.dispatchEvent(new Event('change', { bubbles: true }))
  preset.dispatchEvent(new Event('input', { bubbles: true }))
  await sleep(3_000)
} else if (smokeCase.includes('skia')) {
  await waitFor(() => {
    const status = document.querySelector('#status')
    return !status || getComputedStyle(status).display === 'none'
  }, 'Skia ready status')
  pointer(canvas, 0.4, 0.5, 0.55, 0.55)
} else if (smokeCase.includes('slug-text')) {
  const handle = splitHandle()
  assert(handle, 'Slug split handle is missing')
  const before = handle.getBoundingClientRect().left
  await drag(handle)
  await sleep(100)
  const after = handle.getBoundingClientRect().left
  assert(before !== after, 'Slug split handle did not move')
} else if (smokeCase.includes('tilemap')) {
  const event = new WheelEvent('wheel', { bubbles: true, cancelable: true, clientX: 640, clientY: 360, ctrlKey: true, deltaY: -80 })
  canvas.dispatchEvent(event)
  await waitFor(() => document.body.textContent?.includes('Tilemap'), 'Tilemap controls')
} else if (smokeCase.includes('tsl-nodes')) {
  document.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, code: 'Digit2', key: '2' }))
  document.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, code: 'Digit2', key: '2' }))
  await sleep(750)
} else if (smokeCase.includes('template')) {
  const tint = await waitFor(
    () => [...document.querySelectorAll('.tp-colv_h input.tp-txtv_i')].find(isVisible),
    'tint color control'
  )
  tint.focus()
  tint.value = '#00ffff'
  tint.dispatchEvent(new Event('input', { bubbles: true }))
  tint.dispatchEvent(new Event('change', { bubbles: true }))
  tint.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, code: 'Enter', key: 'Enter' }))
  tint.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, code: 'Enter', key: 'Enter' }))
  tint.blur()
  await waitFor(
    () => document.querySelector('.tp-colswv_sw')?.getAttribute('style')?.includes('0, 255, 255'),
    'cyan tint publication'
  )
} else if (smokeCase.includes('basic-sprite') || smokeCase.startsWith('starter-')) {
  pointer(canvas)
}

await sleep(500)
const canvasesAfter = visibleCanvases()
assert(canvasesAfter.length > 0, 'canvas disappeared after interaction')
await rafSamples()

for (const failure of [
  'This example could not initialize rendering.',
  'This app could not initialize rendering.',
  'Skia WASM not built',
]) {
  const visibleFallback = [...document.querySelectorAll('*')].some(
    (element) => element.children.length === 0 && isVisible(element) && element.textContent?.includes(failure)
  )
  assert(!visibleFallback, `terminal fallback is visible: ${failure}`)
}
assert(runtimeErrors.length === 0, `runtime errors: ${runtimeErrors.join(' | ')}`)

console.log(
  'SMOKE_PASS',
  JSON.stringify({
    case: smokeCase,
    canvases: canvasesAfter.length,
    benchmarkFrame: isBenchmark ? window.__THREE_FLATLAND_BENCHMARK_FRAME__ : null,
    path: location.pathname,
  })
)
